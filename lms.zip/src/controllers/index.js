module.exports.authController = require('./auth.controller');
module.exports.userController = require('./user.controller');
module.exports.videoController = require('./video.controller');
module.exports.planvideoController = require('./planvideo.controller');
module.exports.boardController = require('./board.controller');
module.exports.classesController = require('./classes.controller');

