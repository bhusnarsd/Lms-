module.exports.authService = require('./auth.service');
module.exports.emailService = require('./email.service');
module.exports.tokenService = require('./token.service');
module.exports.userService = require('./user.service');
module.exports.videoService = require('./video.service');
module.exports.planvideoService = require('./planvideo.service');
module.exports.boardService = require('./board.service');
module.exports.classesService = require('./classes.service');
